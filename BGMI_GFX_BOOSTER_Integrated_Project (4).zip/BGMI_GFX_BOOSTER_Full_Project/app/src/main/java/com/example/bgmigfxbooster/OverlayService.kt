package com.example.bgmigfxbooster

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private var expanded = false

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showHandle()
    }

    private fun params(width: Int, height: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER_VERTICAL or Gravity.START; x = 0; y = 0 }
    }

    private fun showHandle() {
        val handle = TextView(this).apply {
            text = "☰"
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xDD202631.toInt())
            setPadding(18, 24, 18, 24)
            setOnClickListener { showPanel() }
        }
        panel = handle
        windowManager.addView(handle, params(WRAP, WRAP))
    }

    private fun showPanel() {
        panel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(0xEE151B25.toInt())
        }
        val title = TextView(this).apply {
            text = "BGMI QUICK PANEL  ✕"
            textSize = 16f
            setTextColor(0xFFFFD166.toInt())
            setPadding(8, 10, 8, 16)
            setOnClickListener { showHandle() }
        }
        box.addView(title)
        listOf("HIGH", "MID", "LOW", "SENSITIVITY", "CLOSE PANEL").forEach { label ->
            val b = Button(this).apply { text = label }
            b.setOnClickListener {
                when (label) {
                    "SENSITIVITY" -> {
                        val i = Intent(this, SensitivityActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                    }
                    "CLOSE PANEL" -> showHandle()
                    else -> getSharedPreferences("booster", MODE_PRIVATE).edit().putString("mode", label).apply()
                }
            }
            box.addView(b)
        }
        panel = box
        windowManager.addView(box, params(WRAP, WRAP))
    }

    override fun onDestroy() {
        panel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object { private const val WRAP = WindowManager.LayoutParams.WRAP_CONTENT }
}
