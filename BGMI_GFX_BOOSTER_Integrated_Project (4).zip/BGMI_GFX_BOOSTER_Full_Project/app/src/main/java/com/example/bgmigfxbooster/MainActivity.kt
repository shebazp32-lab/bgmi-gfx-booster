package com.example.bgmigfxbooster

import android.app.Activity
import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {
    private val bgmiPackage = "com.pubg.imobile"
    private lateinit var monitor: TextView
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            updateMonitor()
            handler.postDelayed(this, 3000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        monitor = findViewById(R.id.tvMonitor)
        status = findViewById(R.id.tvStatus)

        findViewById<Button>(R.id.btnHigh).setOnClickListener { selectMode("HIGH") }
        findViewById<Button>(R.id.btnMid).setOnClickListener { selectMode("MID") }
        findViewById<Button>(R.id.btnLow).setOnClickListener { selectMode("LOW") }

        findViewById<Button>(R.id.btnBoost).setOnClickListener {
            updateMonitor()
            status.text = "SAFE CHECK COMPLETE — Android controls background apps; no forced RAM clear or overclock."
            Toast.makeText(this, "सुरक्षित मॉनिटर अपडेट किया गया।", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnLaunch).setOnClickListener { launchBgmi() }
        findViewById<Button>(R.id.btnSensitivity).setOnClickListener {
            startActivity(Intent(this, SensitivityActivity::class.java))
        }
        findViewById<Button>(R.id.btnSmooth).setOnClickListener {
            status.text = "SUPER SMOOTH: BGMI Settings > Graphics में Smooth चुनें और उपलब्ध स्थिर FPS विकल्प चुनें।"
        }
        findViewById<Button>(R.id.btnOverlay).setOnClickListener { enableOverlay() }
        findViewById<Button>(R.id.btnDnd).setOnClickListener { openDndSettings() }
        findViewById<Button>(R.id.btnBrightness).setOnClickListener {
            startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        }
        findViewById<Button>(R.id.btnFps).setOnClickListener {
            status.text = "BGMI का वास्तविक FPS इस ऐप को सामान्य Android API से उपलब्ध नहीं है। कोई नकली FPS नहीं दिखाया जाएगा।"
        }
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(refresh)
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    private fun selectMode(mode: String) {
        getSharedPreferences("booster", MODE_PRIVATE).edit().putString("mode", mode).apply()
        status.text = "$mode mode selected. यह ऐप के monitor/profile को बदलता है; BGMI की internal graphics नहीं।"
    }

    private fun updateMonitor() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)
        val total = mem.totalMem / (1024 * 1024)
        val free = mem.availMem / (1024 * 1024)
        val usedPercent = if (total > 0) ((total - free) * 100 / total) else 0
        val battery = getSystemService(BATTERY_SERVICE) as BatteryManager
        val level = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val intent = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val temp = if (tempTenths >= 0) String.format(Locale.US, "%.1f°C", tempTenths / 10f) else "Unavailable"
        monitor.text = "DEVICE MONITOR\nRAM used: $usedPercent%  |  Available: ${free}MB / ${total}MB\nBattery: $level%  |  Battery temperature: $temp\nBGMI FPS: Not available to this app"
    }

    private fun launchBgmi() {
        val launch = packageManager.getLaunchIntentForPackage(bgmiPackage)
        if (launch != null) startActivity(launch)
        else status.text = "BGMI installed नहीं मिला। Package ID की जाँच करें।"
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"))
            startActivity(intent)
            status.text = "Side panel के लिए 'Display over other apps' अनुमति दें।"
        } else {
            startService(Intent(this, OverlayService::class.java))
            status.text = "Side gaming panel चालू किया गया।"
        }
    }

    private fun openDndSettings() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            status.text = "DND control के लिए Notification Policy Access दें।"
        } else {
            startActivity(Intent(Settings.ACTION_SOUND_SETTINGS))
            status.text = "DND / Sound settings खोली गईं।"
        }
    }
}
