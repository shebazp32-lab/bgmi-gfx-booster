package com.example.bgmigfxbooster

import android.app.Activity
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.sqrt

class SensitivityActivity : Activity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var gyro: Sensor? = null
    private var testing = false
    private var samples = 0
    private var movementSum = 0.0
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sensitivity)
        val prefs = getSharedPreferences("sensitivity", Context.MODE_PRIVATE)
        bindSlider(R.id.seekCamera, R.id.tvCamera, "Camera", prefs.getInt("camera", 120), "camera")
        bindSlider(R.id.seekAds, R.id.tvAds, "ADS", prefs.getInt("ads", 110), "ads")
        bindSlider(R.id.seekGyro, R.id.tvGyro, "Gyroscope", prefs.getInt("gyro", 250), "gyro")
        bindSlider(R.id.seekGyroAds, R.id.tvGyroAds, "Gyroscope ADS", prefs.getInt("gyroAds", 250), "gyroAds")
        result = findViewById(R.id.tvTest)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        gyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        findViewById<Button>(R.id.btnGyroTest).setOnClickListener { startTest() }
    }

    private fun bindSlider(seekId: Int, textId: Int, label: String, initial: Int, key: String) {
        val seek = findViewById<SeekBar>(seekId)
        val text = findViewById<TextView>(textId)
        seek.progress = initial.coerceIn(0, seek.max)
        fun update(value: Int) { text.text = "$label: $value" }
        update(seek.progress)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                update(value)
                if (fromUser) getSharedPreferences("sensitivity", MODE_PRIVATE).edit().putInt(key, value).apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun startTest() {
        if (gyro == null) {
            result.text = "इस फोन में Gyroscope sensor उपलब्ध नहीं है।"
            return
        }
        samples = 0
        movementSum = 0.0
        testing = true
        sensorManager.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME)
        result.text = "टेस्ट चालू: फोन को धीरे-धीरे घुमाएँ। 5 सेकंड बाद परिणाम आएगा।"
        result.postDelayed({
            sensorManager.unregisterListener(this)
            testing = false
            result.text = if (samples > 0) {
                "Gyroscope detected: ${gyro?.name}\nSamples: $samples\nMovement signal: ${"%.2f".format(movementSum / samples)}\nयह सेंसर गतिविधि का टेस्ट है, BGMI का वास्तविक input delay नहीं।"
            } else "Sensor से डेटा नहीं मिला।"
        }, 5000)
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (!testing) return
        val magnitude = sqrt(event.values.sumOf { (it * it).toDouble() })
        movementSum += magnitude
        samples++
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    override fun onPause() {
        sensorManager.unregisterListener(this)
        testing = false
        super.onPause()
    }
}
