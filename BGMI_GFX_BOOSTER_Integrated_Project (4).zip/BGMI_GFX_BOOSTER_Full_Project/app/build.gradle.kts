plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.bgmigfxbooster"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.bgmigfxbooster"
        minSdk = 23
        targetSdk = 32
        versionCode = 2
        versionName = "2.0"
    }
}
